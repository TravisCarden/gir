The official Invader Zim font direct from Nickelodeon!

Just drop it in c:\windows\fonts and you'll be all set!

Provided by wormbaby.com with special thanks to all the Nick Space Monkeys who make this possible!